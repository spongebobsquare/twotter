import { use } from 'echarts/lib/echarts';
import { install } from './globe/install';
use(install);