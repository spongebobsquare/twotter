import { use } from 'echarts/lib/echarts';
import { install } from './grid3D/install';
use(install);