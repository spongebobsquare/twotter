import { use } from 'echarts/lib/echarts';
import { install } from './mapbox3D/install';
use(install);