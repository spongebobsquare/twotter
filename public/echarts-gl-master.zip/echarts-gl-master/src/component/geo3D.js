import { use } from 'echarts/lib/echarts';
import { install } from './geo3D/install';
use(install);