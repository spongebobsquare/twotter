// Thanks to https://gitee.com/iverson_hu/maptalks-echarts-gl
import { use } from 'echarts/lib/echarts';
import { install } from './maptalks3D/install';
use(install);