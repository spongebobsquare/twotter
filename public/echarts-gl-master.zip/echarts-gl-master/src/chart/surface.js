import { use } from 'echarts/lib/echarts';
import { install } from './surface/install';
use(install);