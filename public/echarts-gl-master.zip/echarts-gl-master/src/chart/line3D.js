import { use } from 'echarts/lib/echarts';
import { install } from './line3D/install';
use(install);