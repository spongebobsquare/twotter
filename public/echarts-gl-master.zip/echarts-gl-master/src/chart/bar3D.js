import { use } from 'echarts/lib/echarts';
import { install } from './bar3D/install';
use(install);