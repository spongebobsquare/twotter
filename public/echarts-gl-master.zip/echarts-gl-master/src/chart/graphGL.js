import { use } from 'echarts/lib/echarts';
import { install } from './graphGL/install';
use(install);