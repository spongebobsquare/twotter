import { use } from 'echarts/lib/echarts';
import { install } from './flowGL/install';
use(install);