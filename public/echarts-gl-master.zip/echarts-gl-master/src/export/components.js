export { install as Grid3DComponent} from '../component/grid3D/install';
export { install as Geo3DComponent} from '../component/geo3D/install';
export { install as GlobeComponent} from '../component/globe/install';
export { install as Mapbox3DComponent} from '../component/mapbox3D/install';
export { install as Maptalks3DComponent} from '../component/maptalks3D/install';
